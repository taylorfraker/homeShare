folder contents:
	
	groupProject2.py: defines all necessary functions and outputs to a csv file

	groupProject2.csv: contains the results of groupProject2.py

	CompareAuthorSignatures.py: retrieves information from referenced csv file (to save comp time), normalizes it, then organizes it into each author's individual signature to be used in the final comparing function







