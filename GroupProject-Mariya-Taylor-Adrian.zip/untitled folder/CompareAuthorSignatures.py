"""

File name: CompareAuthorSignatures.py
Authors: Taylor Fraker, Mariya Garbuz, Adrian Correa
Data Created: 10/29/2018
Last Modified: 10/30/2018
Python ver: 3.6.6

"""

if __name__ == '__main__':

	import csv
	import math
	import pandas as pd

	fieldnames = ['Author','AWL', 'word', 'num', 'punct', 'HL', 'ASL', 'sComp', 'LD']
	col = pd.read_csv('groupProject2.csv', usecols = fieldnames)

	def normalize(lst):
		'''noramlize values in a list'''
		mini = min(lst)
		maxi = max(lst)
		normies = []
		for n in lst:
			x = float(format((n - mini)/(maxi - mini), '.2g'))
			normies.append(x)
		return normies

	Author = [n for n in col.Author]
	AWL = normalize([n for n in col.AWL])
	word = normalize([n for n in col.word])
	num = normalize([n for n in col.num])
	punct = normalize([n for n in col.punct])
	HL = normalize([n for n in col.HL])
	ASL = normalize([n for n in col.ASL])
	sComp = normalize([n for n in col.sComp])
	LD = normalize([n for n in col.LD])

	listAll = ([Author]+[AWL]+[word]+[num]+[punct]+[HL]+[ASL]+[sComp]+[LD])

	'''
	indv author sigs
	'''
	austen = []
	bible = []
	blake = []
	bryant = []
	burgess = []
	carroll = []
	chesterton = []
	edgeworth = []
	melville = []
	milton = []
	shakespeare = []
	whitman = []

	for i in listAll:
		'''
		compile the normailzed values into the author's sigs
		'''
		austen.append(i[0])
		bible.append(i[1])
		blake.append(i[2])
		bryant.append(i[3])
		burgess.append(i[4])
		carroll.append(i[5])
		chesterton.append(i[6])
		edgeworth.append(i[7])
		melville.append(i[8])
		milton.append(i[9])
		shakespeare.append(i[10])
		whitman.append(i[11])

	#weight parameters: Author[0] AWL[1], word[2], num[3], punct[4], HL[5], ASL[6], sComp[7], LD[8]
	
	weights = [0,5,2,3,5,10,50,30,5]

	def compare_signatures(sig1, sig2, weight):
	    '''
	    Return a non-negative real number indicating the similarity of two 
	    linguistic signatures. The smaller the number the more similar the 
	    signatures. Zero indicates identical signatures.
	    sig1 and sig2 are 6 element lists with the following elements
	    0  : author name (a string)
	    1  : average word length (float) --- done
	    2  : TTR (list of floats) --- done
	    3  : Hapax Legomana Ratio (float) --- done
	    4  : average sentence length (float) --- done
	    5  : average sentence complexity (float) --- done
	    6  : lexcial diversity (float) --- done
	    weight is a list of multiplicative weights to apply to each
	    linguistic feature. weight[0] is ignored.
	    '''
	    n_fields = len(sig1)
	    score = 0.0
	    for i in range(1,n_fields):
	        score += abs(sig1[i] - sig2[i])*weight[i]
	        
	    return  score







