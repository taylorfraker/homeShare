"""

File name: groupProject2.py
Authors: Taylor Fraker, Mariya Garbuz, Adrian Correa
Data Created: 10/23/2018
Last Modified: 10/24/2018
Python ver: 3.6.6

"""

import nltk
from nltk.corpus import gutenberg


def author_name(file_id):
    return file_id[:file_id.index('-')]


def average_word_length(words):
    wordLengths = []
    for w in words:
        wordLengths.append(len(w))
    awl = sum(wordLengths)/len(wordLengths)
    return awl


def TTR(tokens):
    '''
    find the ratios of alpha, neumeric, and punctuation in a text
    '''
    alphaList = []
    digitList = []
    puncList = []
    
    for token in tokens:
        if token.isalpha() == True:
            alphaList.append(token)
        elif token.isdigit() == True:
            digitList.append(token)
        else:
            puncList.append(token)
    ttr = [len(alphaList)/len(tokens), len(digitList)/len(tokens), len(puncList)/len(tokens)]

    return ttr


def Hapax_Legomana_Ratio(words):
    '''
    find the ratio of unique words in a text
    '''
    wordlist = sorted(words)
    lwl = len(wordlist)
    singles = []

    for i in range(lwl - 1):
        if wordlist[i] != wordlist[i + 1] and wordlist[i] != wordlist[i - 1]:
            singles.append(wordlist[i])
    
    if wordlist[lwl - 1] != wordlist[lwl - 2]:
        singles.append(wordlist[lwl - 1])

    return len(singles)/lwl


def average_sent_length(words, sents):
    asl = len(words)/len(sents)
    return asl


def sent_complexity(sents):
    '''
    find the number of sentences that contain the given characters
    '''
    countList = []
    compChars = [',', ':', ';']

    for sent in sents:
        count = 0
        for word in sent:
            if word == ',' or word == ':' or word == ';':
                count += 1
        countList.append(count)
    return sum(countList)/len(countList)



def lexical_div(words):
    '''
    compute the lexical diversity for a files in 
    the gutenberg corpus.  
    '''
    n_words = len(words)
    n_vocab = len(set(words))
    l_div = n_vocab / n_words  
    return l_div


def features(file_id):
    '''
    perform previous functions on each text in the gutenberg corpus
    '''
    sents = gutenberg.sents(file_id)
    tokens = gutenberg.words(file_id)
    words = [w for w in tokens if w.isalpha() == True]
    features = []
    features.append(author_name(file_id))
    features.append(float(format(average_word_length(words), '.2g')))
    ttr = TTR(tokens)
    features.append(float(format(ttr[0], '.2g')))
    features.append(float(format(ttr[1], '.2g')))
    features.append(float(format(ttr[2], '.2g')))
    features.append(float(format(Hapax_Legomana_Ratio(words), '.2g')))
    features.append(float(format(average_sent_length(words, sents), '.2g')))
    features.append(float(format(sent_complexity(sents), '.2g')))
    features.append(float(format(lexical_div(words), '.2g')))
    return features

def Author_Sig():
    '''
    consolidate features into a dictionary
    '''
    bookLists = [features(file_id) for file_id in gutenberg.fileids()]
    authorsDict = {}

    for book in bookLists:
        if book[0] in authorsDict:
            authorsDict[book[0]].append(book[1:])
        else:
            authorsDict[book[0]] = []
            authorsDict[book[0]].append(book[1:])
    
    for author in authorsDict:
        if len(authorsDict[author]) > 1:
            authorsAvg = []
            for i in range(len(authorsDict[author][0])):
                x = []
                for book in authorsDict[author]:
                    x.append(book[i])
                authorsAvg.append(float(format(sum(x)/len(x), '.2g')))
            authorsDict[author] = authorsAvg
        else:
            authorsDict[author] = authorsDict[author][0]
    return authorsDict

def compare_signatures(sig1, sig2, weight):
    '''Return a non-negative real number indicating the similarity of two 
    linguistic signatures. The smaller the number the more similar the 
    signatures. Zero indicates identical signatures.
    sig1 and sig2 are 6 element lists with the following elements
    0  : author name (a string)
    1  : average word length (float) --- done
    2  : TTR (list of floats) --- done
    3  : Hapax Legomana Ratio (float) --- done
    4  : average sentence length (float) --- done
    5  : average sentence complexity (float) --- done
    6  : lexcial diversity (float) --- done
    weight is a list of multiplicative weights to apply to each
    linguistic feature. weight[0] is ignored.
    '''
    n_fields = len(sig1)
    score = 0.0
    for i in range(1,n_fields):
        score += abs(sig1[i] - sig2[i])*weight[i]
        
    return  score

def table():
    '''
    format dictionary for readability in interpreter
    '''
    aSig = Author_Sig()
    print("Author        AWL   word  num      punct  HL     ASL    sComp  LD  ")
    for key in aSig:
        f = aSig[key]
        print('{:<14}{:<6}{:<7}{:<10}{:<8}{:<8}{:<7}{:<7}{:<4}'.format(key, f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7]))
    print('\nKey:\nAWL: average word length\nword/:word ratio\nnum/: number ratio\npunct/: punctuation ratio\nHL/: Hapax Legomana ratio\nASL: average sentence length\nsComp: sentence complexity\nLD: lexical diversity')

if __name__ == '__main__':

    import csv

    aSig = Author_Sig()

    csvfile = open('groupProject2.csv', 'w')
    with csvfile:
        fieldnames = ['Author','AWL', 'word', 'num', 'punct', 'HL', 'ASL', 'sComp', 'LD']
        w = csv.DictWriter(csvfile, fieldnames = fieldnames)

        w.writeheader()
        for key in aSig:
            f = aSig[key]
            w.writerow({'Author': key, 'AWL': f[0], 'word': f[1], 'num': f[2], 'punct': f[3], 'HL': f[4], 'ASL': f[5], 'sComp': f[6], 'LD': f[7]})


    csvfile.close()
    print('File writing is done! Check the current directory')







